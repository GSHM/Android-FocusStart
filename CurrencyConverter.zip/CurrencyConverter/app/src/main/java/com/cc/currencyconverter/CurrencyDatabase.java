/**
 * Класс взаимодествия с базой данных.
 * Осушествляет подключение, чтение и запись БД
 * */

package com.cc.currencyconverter;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class CurrencyDatabase {

    private HelperDatabase helperDatabase;


   public CurrencyDatabase (Context context) {

       helperDatabase = new HelperDatabase(context);
   }

    // Метод записи информации в БД
   public void writeDatabase(ArrayList<Currency> currencies) {

       SQLiteDatabase database = helperDatabase.getWritableDatabase();                              // открыть БД для записи

       database.delete(HelperDatabase.TABLE_VALUTE, null, null);              // удалить старые записи из БД

       for (int i = 0; i < currencies.size(); i++) {

           ContentValues contentValues = new ContentValues();                                       // добавить новую строку в таблицу
           // заполнение колонок
           contentValues.put(HelperDatabase.KEY_CHARCODE, currencies.get(i).getCharCode());
           contentValues.put(HelperDatabase.KEY_NAME, currencies.get(i).getName());
           contentValues.put(HelperDatabase.KEY_NOMINAL, currencies.get(i).getNominal());
           contentValues.put(HelperDatabase.KEY_VALUE, currencies.get(i).getValue());

           database.insert(HelperDatabase.TABLE_VALUTE, null, contentValues);        // выполнить запрос
       }
       helperDatabase.close();
   }

    // Метод чтения информации из БД
    public ArrayList<Currency> readDatabase() {

        ArrayList<Currency> currencies = new ArrayList();

        SQLiteDatabase database = helperDatabase.getReadableDatabase();                              // открыть БД для чтения

        Cursor cursor = database.query(HelperDatabase.TABLE_VALUTE, null,
                null, null, null, null, null);

        if (cursor.moveToFirst()) {                                                                  // выполнить если есть запись (строка)
            int nameIndex = cursor.getColumnIndex(HelperDatabase.KEY_NAME);
            int charcodeIndex = cursor.getColumnIndex(HelperDatabase.KEY_CHARCODE);
            int nominalIndex = cursor.getColumnIndex(HelperDatabase.KEY_NOMINAL);
            int valueIndex = cursor.getColumnIndex(HelperDatabase.KEY_VALUE);

            while (cursor.moveToNext()) {                                                            // выполнять пока в БД есть строки

                String name = cursor.getString(nameIndex);                                           // получим имя валюты
                String charCode = cursor.getString(charcodeIndex);                                   // получим код валюты
                int nominal = cursor.getInt(nominalIndex);                                           // получим курс валюты
                double value = cursor.getDouble(valueIndex);                                         // получим номинал валюты

                currencies.add(new Currency(charCode, name, nominal, value));
            }
        }
        cursor.close();
        helperDatabase.close();

        return currencies;
    }

    public void clearDB () {

        SQLiteDatabase database = helperDatabase.getWritableDatabase();
        database.delete(HelperDatabase.TABLE_VALUTE, null, null);
        helperDatabase.close();

    }


}
