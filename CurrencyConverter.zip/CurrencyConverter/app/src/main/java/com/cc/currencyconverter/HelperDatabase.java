package com.cc.currencyconverter;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class HelperDatabase extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Currency";
    public static final String TABLE_VALUTE = "Valute";

    public static final String KEY_ID_DB = "_id";                                                    // id базы данных

    public static final String KEY_ID = "ID";                                                        // id валюты
    public static final String KEY_NUMCODE= "NumCode";
    public static final String KEY_CHARCODE = "CharCode";
    public static final String KEY_NOMINAL = "Nominal";
    public static final String KEY_NAME = "Name";
    public static final String KEY_VALUE = "Value";
    public static final String KEY_PREVIOUS = "Previous";

    public HelperDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {                                                       // метод вызываеться если базы данных не сушествует

        // SQL - запрос на создание таблицы
        db.execSQL("CREATE TABLE " + TABLE_VALUTE + "(" +
                KEY_ID_DB + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                KEY_NAME + " TEXT," +
                KEY_CHARCODE + " TEXT," +
                KEY_VALUE + " REAL," +
                KEY_NOMINAL + " INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {                      // метод вызываеться если изменена версия БД

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VALUTE);                                         // запрос в базу данных на уничтожение таблицы
        onCreate(db);
    }

}
