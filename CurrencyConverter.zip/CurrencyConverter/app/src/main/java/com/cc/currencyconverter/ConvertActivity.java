/**
 * ConvertActivity - вызывается из MainActivity. Выполнят пересчет указанной суммы пользователем в рубли и обратно.
 * Методы класса:
 * * getDataPreviousActivity - получить выбранную пользователем валюту из предыдушего экрана.
 *  Пересчет валюты осуществляется в теле обработчика нажатия кнопки
 * */

package com.cc.currencyconverter;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ConvertActivity extends AppCompatActivity {

    private double convertValute;                                                                   // конвертированная сумма в другой валюте
    private double amountMoney;                                                                     // вводимый пользователем к-во денег необходимых для конвертации в другую валюту
    private double course;                                                                          // курс иностранной валюты

    private Button converButton;
    private Button clearButton;
    private TextView carrencyViewText;
    private TextView valueViewText;
    private TextView charCodeViewText;
    private EditText rubEditText;
    private EditText valEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convert);

        // инициализация графических компонентов
        carrencyViewText = (TextView) findViewById(R.id.textValute);
        valueViewText = (TextView) findViewById(R.id.textValue);
        charCodeViewText = (TextView) findViewById(R.id.textCharCode);
        rubEditText = (EditText) findViewById(R.id.textDecimalRub);
        valEditText = (EditText) findViewById(R.id.textDecimalInVal);
        converButton = (Button) findViewById(R.id.convertButton);
        clearButton = (Button) findViewById(R.id.clearButton);

        converButton.setOnClickListener(this::onClick);
        clearButton.setOnClickListener(this::onClick);

        getDataPreviousActivity();                                                                  // получить данные о валюте (с главного окна)
    }

    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.convertButton:

                // Пользователь заполнил:
                if (rubEditText.length() != 0 && valEditText.length() != 0) {                       // * обе строчки

                   // код обработки

                } else if (rubEditText.length() != 0) {                                             // * строчку в рублях

                    amountMoney = extractEditText(rubEditText);                                     //  суммва в рублях
                    convertValute = amountMoney * course;                                           // - получим к-во иностранной валюты за рубли
                    valEditText.setText(convertString(convertValute));

                } else if (valEditText.length() != 0) {                                             // * строчку в иностранной валюте

                    amountMoney = extractEditText(valEditText);                                     // сумма в валюте
                    convertValute = amountMoney / course;                                           // - получим к-во рублей за валюту
                    rubEditText.setText(convertString(convertValute));
                }
                break;
            case R.id.clearButton:                                                                  // - очищаем
                rubEditText.setText("");
                valEditText.setText("");
                break;
        }
    }

    // Метод получения данных с предыдушего активного окна
    private void getDataPreviousActivity () {

        Bundle arguments = getIntent().getExtras();                                                 // получить отправленные данные с главного экрана

        Currency currency;                                                                          // хранение данных (валюта) принытых с главного экрана

        if (arguments != null) {
            currency = (Currency) arguments.getSerializable(Currency.class.getSimpleName());        // получить данные в виде валюты по ключу класса

            // обрабатываем, устанавливаем принятые данные
            double valueCurrency = currency.getValue();
            int nominalCurrency = currency.getNominal();
            course  = valueCurrency / nominalCurrency;
            carrencyViewText.setText(currency.getName());
            valueViewText.setText("Курс: " + convertString(course));
            charCodeViewText.setText(currency.getCharCode() + ":");
        }
    }

    private double extractEditText (EditText editText) {

        String strVal = editText.getText().toString();
        double doublVal =  Double.parseDouble (strVal);
        return doublVal;
    }

    private String convertString (double convertValute) {

        String convertVal = convertValute + "";
        return convertVal;
    }

}
