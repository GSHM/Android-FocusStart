/** CurrencyAdapter - связывает данные о валютах (ArrayList<Currency>) и список (RecyclerView) */

package com.cc.currencyconverter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CurrencyAdapter extends RecyclerView.Adapter<CurrencyAdapter.CurrencyViewHolder> {  // Указажем собственный ViewHolder, который предоставит доступ к View-компонентам

    private Context context;
    private ArrayList<Currency> currencies;
    private OnCurrencyClickListener onClickListener;                        // переменная для хранения объекта интерфейса

    public interface OnCurrencyClickListener {
        void OnCurrencyClick(Currency currency, int position);              // вызывается при выборе объекта currency, получает объект currency и его позицию
    }

    public CurrencyAdapter(Context context, OnCurrencyClickListener onClickListener) {
        currencies = new ArrayList();
        this.context = context;
        this.onClickListener = onClickListener;
    }

    public CurrencyAdapter(Context context, OnCurrencyClickListener onClickListener, ArrayList<Currency> currencies) {
        this.context = context;
        this.onClickListener = onClickListener;
        this.currencies = currencies;
    }

    @NonNull
    @Override
    // Метод создания объекта ViewHolder. Принимает созданный View-компонент, с которым в дальнейшем будут связываться java объекты. Вызывается автоматический
    public CurrencyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row,parent,false);
        CurrencyViewHolder myHolder = new CurrencyViewHolder(view);
        return myHolder;
    }

    @Override
    // Мето связи java объекта и View. Вызывается автоматический.
    public void onBindViewHolder(@NonNull CurrencyViewHolder holder, int position) {
        Currency currency = currencies.get(position);
        holder.nameView.setText(currency.getName());

        // обработка нажатия
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                onClickListener.OnCurrencyClick(currency, position);                                 // вызываем метод слушателя, передавая ему данные
            }
        });
    }

    @Override
    // Количество элементов в списке.
    public int getItemCount() {
        return currencies.size();
    }

    // Добавить содержание списка
    public void setItems(ArrayList<Currency> currencies) {
        this.currencies = currencies;
        notifyDataSetChanged();                     // список элементов изменился - перерисовать
    }

    // Предоставляет прямую ссылку на каждый View-компонент
    // Используется для кэширования View-компонентов и последующего быстрого доступа к ним
    // CurrencyViewHolder содержит переменные для View-компонентов, которые используются в работе со списком
    public class CurrencyViewHolder extends RecyclerView.ViewHolder {

        TextView nameView;

        // Конструктор принимает View-компонент строки
        public CurrencyViewHolder(@NonNull View itemView) {
            super(itemView);
            nameView = itemView.findViewById(R.id.name);
        }
    }

}