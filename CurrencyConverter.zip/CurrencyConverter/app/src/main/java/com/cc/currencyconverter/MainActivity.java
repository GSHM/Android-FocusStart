/**
 *  MainActivity - стартовый экран на котором отображается список валют (RecyclerView).
 *  Интерфейс пользователя:
 *  *  кнопка обновить - вызов метода loadCurrencies - пользователь получит обновленный список валют
 *  *  клик по элементу списка - переход на новое окно ConvertActivity - конвертация выбранной валюты в рубли и обратно
 *
 *  Методы класса:
 *  *  updateCurrency - выполняет переодическое обновление дынных о валютах. (переодический вызовает метод loadCurrencies).
 *  принимает параметры: время начала работы обновления и время интервала обновления.
 *  *  loadCurrencies - выполняет сетевой запрос на сайт ЦБ. В качеств параметра принимает адресс запроса.
 *  onResponse - обработчик положительного ответа на запрос. В качеств параметра принимает ответ на запрос ввиде строки.
 *  тело обработчика: обработка данных JSON формата (метод getKeyValute),
 *  помещение данных на экран пользователя (вызов метода setItems класса СurrencyAdapter),
 *  запись информации о валютах в базу данных (вызов метода writeDatabase, класса СurrencyDatabase).
 *  onErrorResponse - обработчик ошибки.
 *  * getKeyValute - метод получения ключей валют, необходимых для извлечения данных формата JSON
 *  Принимает - объект JSON
 *  Возврашает - массив строк с ключами валют.
 *
 *  Логика работы приложения:
 *  При запуске приложения данные о валютах постпают из базы данных (метод readDatabase, класса СurrencyDatabase),
 *  если БД пуста - список отобразится пустым.
 *  Через 10 секунд после запуска приложения, произойдет отправка сетевого запроса (strRequest).
 *  Если запрос успешен - извлекуться данные о валютах из JSON формата и с помощью адаптера (СurrencyAdapter) поместяться в список (RecyclerView).
 *  Следом, новые данные сохранятся в БД (метод writeDatabase, класса СurrencyDatabase).
 *  Интервал обновления данных состовляет 1 минута.
 *
 *  Пользователь может самостоятельно получить актуальные данные о валютах путем нажатия на кнопку.
 *  Пользователь может конвертировать валюту кликнув на элемент списка
 * */

package com.cc.currencyconverter;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private static final String JSON_URL = "https://www.cbr-xml-daily.ru/daily_json.js";

    private ArrayList<Currency> currencies;                                            // список валют
    private CurrencyDatabase currencyDatabase;                                         // база данных (sqlite)

    private RecyclerView recyclerView;                                                // графический компонент - список
    private CurrencyAdapter сurrencyAdapter;                                          // адаптер для граф. компонента

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currencies = new ArrayList();
        currencyDatabase = new CurrencyDatabase(this);

        initView();                                                                    // инициализация графических компонентов

        // При запуске приложение данные о валютах беруться из базы данных
        currencies = currencyDatabase.readDatabase();                                 // получить информацию о валютах из БД
        сurrencyAdapter.setItems(currencies);                                         // поместить данные о валютах на графический компонент

        // Через 10 секунд происходит получение актуальных данных с сервера.
        // Переодичность обновления данных состовляет 1 минута.
        updateCurrency(10000, 60000);                               // периодический обновлять данные о валютах с сервера

    }

    // Метод инициализация графических компонентов
    private void initView() {

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));                        //  линейная форма отображения

        // Определим слушатель на список
        CurrencyAdapter.OnCurrencyClickListener onClickListener = new CurrencyAdapter.OnCurrencyClickListener() {
            @Override
            public void OnCurrencyClick(Currency currency, int position) {                           // был выбран элемент списка

                // переход на новое окно
                Intent intent = new Intent(MainActivity.this, ConvertActivity.class);  // создать объект для перехода к новому окну
                intent.putExtra(Currency.class.getSimpleName(), currency);                           // передать новому окну данные: объект currency, по ключу - название его класса
                startActivity(intent);
            }
        };
        // Создать и Установить Адаптер для граф.списка
        сurrencyAdapter = new CurrencyAdapter(MainActivity.this, onClickListener);
        recyclerView.setAdapter(сurrencyAdapter);

        Button updateButton = (Button) findViewById(R.id.update);

        // обновление данных с помощью кнопки
        updateButton.setOnClickListener(new View.OnClickListener() {
           @Override
            public void onClick(View v) {                             // получить данные с сервера при нажатии кнопки

               loadCurrencies(JSON_URL);
           }
        });
    }

    // Метод получения данных о валютах с сервера
    private void loadCurrencies(String url) {

        // Формирование запроса
        StringRequest strRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {                                                    // установить слушатель
                    @Override
                    public void onResponse(String response) {                                        // Пришел ответ:

                        if (currencies.size() != 0)
                            currencies.clear();                                                     // удалить старые данные если они были

                        try {
                            JSONObject objectJSON = new JSONObject(response);                        // создать объект JSON, поместить содержание ответа

                            // Узнаем ключи валют. (т.к. обрашение к ключю происходит по имени)
                            ArrayList<String> codeValute = getKeyValute(objectJSON);                 // имена ключей валют

                            for (int i = 0; i < codeValute.size(); i++) {
                                String charCode = objectJSON.getJSONObject("Valute").getJSONObject(codeValute.get(i)).getString("CharCode");
                                String name = objectJSON.getJSONObject("Valute").getJSONObject(codeValute.get(i)).getString("Name");        // получим имя валюты
                                String nominal = objectJSON.getJSONObject("Valute").getJSONObject(codeValute.get(i)).getString("Nominal");  // получим номинал валюты
                                String value = objectJSON.getJSONObject("Valute").getJSONObject(codeValute.get(i)).getString("Value");      // получим курс валюты
                                currencies.add(new Currency(charCode, name, nominal, value));
                            }
                            сurrencyAdapter.setItems(currencies);                                   // поместить данные о валютах на графический компонент
                            currencyDatabase.writeDatabase(currencies);                             // сохранить информацию о валютах в БД

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {                                                   // установить слушатель на ответ - произошла ошибка
            @Override
            public void onErrorResponse(VolleyError error) {                                         // метод обработки ошибки
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);                           // выполним сетевой запрос
        requestQueue.add(strRequest);                                                               // мой запрос
    }

    // Метод получения именен ключей валют стран из объекта JSON
    private ArrayList<String> getKeyValute(JSONObject objectJSON) {

        ArrayList<String> keyValute = new ArrayList();                            // Список валют (ключи)

        // Узнаем ключи валют.                                                    // Для этого:
        String lineJSON = null;
        try {
            lineJSON = objectJSON.getString("Valute");                     // - получим значение объекта Valute, представим значение в виде строки
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String[] words = lineJSON.split("\"");                             // - поделим на строки по символу - "

        boolean haveLine = false;                                                // Флаг наличия повторной строки: значение ключа валют и ключа чаркода - повторяются

        // Получить ключи всех валют
        for (int i = 0; i < words.length; i++) {                                 // - Выберем из массива строк нужные данные
            // Критерии:
            if (words[i].length() == 3) {                                        // символов в строке = 3

                boolean hasDigit = words[i].matches(".*\\d+.*");

                if (!hasDigit) {                                                 // не должно быть число

                    if (!haveLine) {                                             // нет повторной записи
                        haveLine = true;
                        keyValute.add(words[i]);                                 // - записываем

                    } else
                        haveLine = false;                                        // есть повторная запись - пропускаем, переводим флаг
                }
            }
        }
        return keyValute;
    }

    // Метод периодического получения (обновления) данных
    private void updateCurrency(int startMS, int periodMS) {

        Timer timer = new Timer();

        timer.scheduleAtFixedRate(new TimerTask() {                                                 // Создать задачу:
            @Override
            public void run() {

                runOnUiThread(new Runnable() {                                                       // выполнять в потоке UI
                    @Override
                    public void run() {
                        loadCurrencies(JSON_URL);                                                    //  обновлять данные
                    }
                });
            }
        }, startMS, periodMS);                                                                       // начиная с момента strat, с периодом period
    }

}
