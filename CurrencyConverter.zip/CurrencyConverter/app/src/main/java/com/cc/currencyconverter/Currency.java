package com.cc.currencyconverter;

import java.io.Serializable;

public class Currency implements Serializable {

    private String id;
    private String numCode;
    private String charCode;
    private String name;
    private int nominal;
    private double value;
    private double previous;

    public Currency() {

    }

    public Currency(String charCode, String name, String noninal, String value) {
        this.charCode = charCode;
        this.name = name;
        this.nominal = changeTypeInt(noninal);
        this.value = changeTypeDoubl(value);
    }

    public Currency(String charCode, String name, int nominal, double value) {
        this.charCode = charCode;
        this.name = name;
        this.value = value;
        this.nominal = nominal;
    }


    private int changeTypeInt (String strVal) {

        int intVal = Integer.parseInt(strVal);
        return intVal;
    }

    private double changeTypeDoubl (String strVal) {

        double doublVal  = Double.parseDouble (strVal);
        return doublVal;
    }


    public int getNominal() {
        return nominal;
    }

    public String getName() {
        return name;
    }

    public double getValue() {
        return value;
    }

    public String getCharCode() {
        return charCode;
    }


}


